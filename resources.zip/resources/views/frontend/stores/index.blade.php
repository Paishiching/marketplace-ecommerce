{{-- stores/index.blade.php --}}
