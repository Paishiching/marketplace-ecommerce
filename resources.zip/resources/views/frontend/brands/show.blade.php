{{-- brands/shop.blade.php --}}
