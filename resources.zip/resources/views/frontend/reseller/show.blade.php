{{-- reseller/shop.blade.php --}}
