{{-- blog/shop.blade.php --}}
