{{-- faq/index.blade.php --}}
