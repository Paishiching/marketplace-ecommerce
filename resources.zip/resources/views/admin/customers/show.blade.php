{{-- customers/shop.blade.php --}}
