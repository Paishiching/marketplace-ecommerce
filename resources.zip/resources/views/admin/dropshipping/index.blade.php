{{-- dropshipping/index.blade.php --}}
