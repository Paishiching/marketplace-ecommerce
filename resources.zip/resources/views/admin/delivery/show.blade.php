{{-- delivery/shop.blade.php --}}
