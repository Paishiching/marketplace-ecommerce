{{-- resellers/shop.blade.php --}}
