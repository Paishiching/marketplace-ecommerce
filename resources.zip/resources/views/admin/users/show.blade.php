{{-- users/shop.blade.php --}}
