{{-- marketing/shop.blade.php --}}
