{{-- reviews/shop.blade.php --}}
