{{-- affiliates/shop.blade.php --}}
