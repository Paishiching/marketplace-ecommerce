{{-- customer/footer.blade.php --}}
