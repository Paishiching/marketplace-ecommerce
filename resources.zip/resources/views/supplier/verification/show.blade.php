{{-- verification/shop.blade.php --}}
