{{-- shipments/index.blade.php --}}
