{{-- shipments/shop.blade.php --}}
