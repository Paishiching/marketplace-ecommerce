{{-- inventory/index.blade.php --}}
