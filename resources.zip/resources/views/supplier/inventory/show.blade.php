{{-- inventory/shop.blade.php --}}
