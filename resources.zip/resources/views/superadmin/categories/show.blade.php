{{-- categories/shop.blade.php --}}
