{{-- receipts/shop.blade.php --}}
