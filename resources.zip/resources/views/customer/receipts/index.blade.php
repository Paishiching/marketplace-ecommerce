{{-- receipts/index.blade.php --}}
